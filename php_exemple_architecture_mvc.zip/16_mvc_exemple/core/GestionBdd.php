<?php
function gerer_exceptionSQL(PDOException $erreur): void
{
    // Afficher les erreurs dans le navigateur uniquement en mode développement :
    if (defined('DEV_MODE') && DEV_MODE === true)
    {
        echo '<div style="background-color: #e6c4c4; padding: 10px; margin: 10px;">';
        echo '<strong>Erreur d\'exécution de requête :</strong> ' . $erreur->getMessage();
        echo '</div>';
    }

    // Monter le message d'erreur pour le journal.
    $messageErreur = '[' . date('Y-m-d H:i:s') . '] Erreur d\'exécution de requête : ' . $erreur->getMessage() . PHP_EOL;

    // Enregistrer le message d'erreur dans le journal (fichier sql.log).
    // L'utilisation du chiffre 3 en deuxième paramètre signifie que le message sera ajouté à la fin du fichier spécifié (le fichier sera créé s'il n'existe pas).
    error_log($messageErreur, 3, dirname(__DIR__) . DIRECTORY_SEPARATOR . 'logs' . DIRECTORY_SEPARATOR . 'sql.log');
}

function charger_bdd(): ?PDO
{
    // Importer le contenu du fichier de configuration.
    $config = file_get_contents(dirname(__DIR__) . DIRECTORY_SEPARATOR . 'config' . DIRECTORY_SEPARATOR . 'config.json');

    // Convertir la configuration qui est une chaîne de caractères en un tableau associatif et cibler la propriété "BDD".
    $config = json_decode($config, true)['bdd'];

    try
    {
        $pdo = new \PDO("mysql:host={$config['serveur']};dbname={$config['bdd']};charset=utf8", $config['utilisateur'], $config['motDePasse']);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

        return $pdo;
    }
    catch(PDOException $erreur)
    {
        // Relancer l'exception pour qu'elle soit capturée par la fonction parente.
        throw $erreur;
    }
}

function est_uniqueDansTable(string $table, string $colonne, string $valeur, ?string $idCol = null, ?int $idVal = null): bool
{
    try
    {
        $pdo = charger_bdd();

        // Préparer la requête SQL :
        $requete = "SELECT * FROM $table WHERE $colonne = :valeur";
        $stmt = $pdo->prepare($requete);
        $stmt->bindValue(':valeur', $valeur, \PDO::PARAM_STR);

        $stmt->execute();
        $resultat = $stmt->fetch(\PDO::FETCH_ASSOC);

        // Retourne "true" si aucune ligne n'a été trouvée suite à la requête ou si une ligne a été trouvée mais que les arguments "$idCol" et "$idVal" ont été passés. 
        // De plus, il vérifie si la "$idCol" correspond au nom de la colonne "ID" de la base de données et que "$idVal" est identique à la valeur de cette même colonne.
        // Cette vérification est utile pour les opérations de modification telles que les changements de mot de passe.
        return $resultat === false 
            || ($idVal !== null
                && $idCol !== null
                && isset($resultat[$idCol])
                && $resultat[$idCol] === $idVal);
    }
    catch (\PDOException $erreur)
    { 
        // Relancer l'exception pour qu'elle soit capturée par la fonction parente.
        throw $erreur;
    }
}

function executer_requete(string $requete, array $parametres, bool $selection): ?PDOStatement 
{
    try
    {
        // Instancier la connexion à la base de données.
        $pdo = charger_bdd();

        // Si aucun paramètre n'est passé en argument, utiliser une simple requête :
        if (empty($parametres))
        {
            // Exécuter la requête en fonction de son type :
            if ($selection)
            {
                $stmt = $pdo->query($requete);
            }
            else
            {
                $stmt = $pdo->exec($requete);
            }
        }
        else
        {
            // Charger la requête préparée.
            $stmt = $pdo->prepare($requete);

            // Lier toutes les valeurs à leur marqueur :
            foreach ($parametres as $marqueur => $valeur)
            {
                $stmt->bindValue(":$marqueur", $valeur);
            }

            // Exécuter la requête.
            $stmt->execute();
        }

        return $stmt;
    }
    catch (PDOException $erreur)
    { 
        // Relancer l'exception pour qu'elle soit capturée par la fonction parente.
        throw $erreur;
    }
}

function selectionner_dansTable(string $requete, ?array $parametres = []): ?array
{
    try
    {
        // Préparer et exécuter la requête.
        $stmt = executer_requete($requete, $parametres, true);

        // Récupérer un tableau avec les données retournées par la requêtes.
        return $stmt->fetchAll(PDO::FETCH_ASSOC);
    }
    catch (PDOException $erreur)
    {
        gerer_exceptionSQL($erreur);
        return null;
    }
}

// Cette fonction permet de réaliser des insertions (insert), des mises à jour (update) ainsi que des suppression (delete).
// La fonction retournera true si une modification a bien été réalisée et false dans le cas contraire.
function modifier_dansTable(string $requete, ?array $parametres = []): bool
{
    try
    {
        // Exécuter la requête et retourner le résultat (true ou false).
        executer_requete($requete, $parametres, false);
        return true;
    }
    catch (PDOException $erreur)
    {
        gerer_exceptionSQL($erreur);
        return false;
    }
}
?>