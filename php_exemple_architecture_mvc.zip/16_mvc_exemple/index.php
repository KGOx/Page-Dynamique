<?php
// Importer le routeur d'URL.
require_once __DIR__ . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'Routeur.php';

// Permet de distinguer le mode développement du mode production.
// Ceci me permet d'utiliser des conditions pour réaliser certaines actions seulement si je suis dans un mode spécifique.
// Par exemple, dans le fichier /core/gestion_bdd.php, les erreurs ne s'afficheront dans le navigateur que si la constante DEV_MODE a été définie et que sa valeur vaut "true".
define('DEV_MODE', true);

// Chemin de base de l'application à appliquer dans toutes les requêtes de ressources côté client (css, images, javascript, ...).
define('BASE_URL', rtrim(str_replace("\\", "/", dirname($_SERVER['SCRIPT_NAME'])), "/"));

// Définir la langue.
define('LANGUE', 'fr');

// Routes :
$patterns = ['id' => '\d+'];
$routes = [
    obtenir_route('GET', '/', 'AccueilController', 'index'),
    obtenir_route('GET', '/admin-gestion-utilisateur', 'AdminGestionUtilisateurController', 'index'),
    obtenir_route('DELETE', '/admin-gestion-utilisateur', 'AdminGestionUtilisateurController', 'detruire'),
    obtenir_route('GET', '/admin-gestion-utilisateur/creer', 'AdminGestionUtilisateurController', 'creer'),
    obtenir_route('POST', '/admin-gestion-utilisateur/creer', 'AdminGestionUtilisateurController', 'stocker'),
    obtenir_route('GET', '/admin-gestion-utilisateur/{id}', 'AdminGestionUtilisateurController', 'montrer'),
    obtenir_route('GET', '/admin-gestion-utilisateur/{id}/editer', 'AdminGestionUtilisateurController', 'editer'),
    obtenir_route('PUT', '/admin-gestion-utilisateur/{id}/editer', 'AdminGestionUtilisateurController', 'actualiser')
];

demarrer_routeur($routes, $patterns);