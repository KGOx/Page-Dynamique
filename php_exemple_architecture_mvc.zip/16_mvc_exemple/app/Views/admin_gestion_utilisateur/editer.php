<h1>Éditer les Données de l'Utilisateur</h1>
<div>
    <form method="POST">
        <input type="hidden" name="_methode" value="put">
        <div>
            <label class="required" for="pseudo">Pseudo </label>
            <input type="text" id="pseudo" name="pseudo" value="<?=$args['utilisateur']['uti_pseudo'] ?? $args['valeursEchapees']['pseudo'] ?? ''?>" <?=$args['accessibilite']['pseudo'] ?? ''?> minlength="2" maxlength="255" required>
            <?=$args['erreurs']['pseudo'] ?? ''?>
        </div>
        <div>
            <label class="required" for="email">E-Mail </label>
            <input type="email" id="email" name="email" value="<?=$args['utilisateur']['uti_email'] ?? $args['valeursEchapees']['email'] ?? ''?>" <?=$args['accessibilite']['email'] ?? ''?> required>
            <?=$args['erreurs']['email'] ?? ''?>
        </div>
        <div>
            <label class="required" for="mdp">Mot de Passe </label>
            <input type="password" id="mdp" name="mdp" <?=$args['accessibilite']['mdp'] ?? ''?> minlength="8" maxlength="72">
            <?=$args['erreurs']['mdp'] ?? ''?>
        </div>
        <div>
            <button type="submit">Modifier</button>
            <?=$args['messageValidation'] ?? ''?>
        </div>
    </form>
</div>