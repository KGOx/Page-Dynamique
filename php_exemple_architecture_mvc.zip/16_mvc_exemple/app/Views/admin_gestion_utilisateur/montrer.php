<h1>Informations de l'Utilisateur</h1>
<div class="montrer-conteneur">
    <ul>
        <li><b>Pseudo : </b><?=$args['utilisateur']['uti_pseudo']?></li>
        <li><b>Email : </b><?=$args['utilisateur']['uti_email']?></li>
    </ul>
    <div>
        <form method="POST">
            <input type="hidden" name="_methode" value="delete">
            <div>
                <a class="btn" href="<?=$pageInfos['baseUrlPage'] . '/' . $args['utilisateur']['uti_id'] . '/editer'?>">Éditer</a>
            </div>
        </form>
    </div>
</div>