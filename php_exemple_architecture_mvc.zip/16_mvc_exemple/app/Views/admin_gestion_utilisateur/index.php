<h1>Gestion des Utilisateurs</h1>
<p><a class="btn" href="<?=$pageInfos['baseUrlPage'] . '/creer'?>">Créer un nouvel utilisateur</a></p>
<h2>Liste des Utilisateurs</h2>
<?php
foreach($args['utilisateurs'] as $utilisateur)
{
    ?>
    <div>
        <form method="POST">
            <input type="hidden" name="_methode" value="delete">
            <input type="hidden" name="id" value="<?=$utilisateur['uti_id']?>">
            <div class="user-row">
                <h3><?=$utilisateur['uti_pseudo']?></h3>
                <div>
                    <a class="btn" href="<?=$pageInfos['baseUrlPage'] . '/' . $utilisateur['uti_id']?>">Détailler</a>
                    <button class="btn-alert" type="submit">Supprimer</button>
                </div>
            </div>
            <?=$args['messageValidation'] ?? ''?>
        </form>
    </div>
    <?php
}