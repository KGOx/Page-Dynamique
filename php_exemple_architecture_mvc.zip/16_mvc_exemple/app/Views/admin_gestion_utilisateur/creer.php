<h1>Créer un Nouvel Utilisateur</h1>
<form method="post">
    <p aria-hidden="true"><span class="alert">*</span> champs obligatoires</p>
    <div>
        <label class="required" for="pseudo">Pseudo </label>
        <input type="text" id="pseudo" name="pseudo" value="<?=$args['valeursEchapees']['pseudo'] ?? ''?>" <?=$args['accessibilite']['pseudo'] ?? ''?> minlength="2" maxlength="255" required>
        <?=$args['erreurs']['pseudo'] ?? ''?>
    </div>
    <div>
        <label class="required" for="email">E-Mail </label>
        <input type="email" id="email" name="email" value="<?=$args['valeursEchapees']['email'] ?? ''?>" <?=$args['accessibilite']['email'] ?? ''?> required>
        <?=$args['erreurs']['email'] ?? ''?>
    </div>
    <div>
        <label class="required" for="mdp">Mot de Passe </label>
        <input type="password" id="mdp" name="mdp" <?=$args['accessibilite']['mdp'] ?? ''?> minlength="8" maxlength="72" required>
        <?=$args['erreurs']['mdp'] ?? ''?>
    </div>
    <div>
        <button type="submit">Créer</button>
        <?=$args['messageValidation'] ?? ''?>
    </div>
</form>