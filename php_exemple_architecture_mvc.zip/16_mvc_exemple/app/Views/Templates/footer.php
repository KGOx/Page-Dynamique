    </main>
    <footer>
        <p>&copy; <a href="https://cours.cvmdev.be" target="_blank" rel="noopener">cours.cvmdev.be</a> - Projet Framework Exemple</p>
    </footer>
</body>
</html> 