<?php
// Importer le gestionnaire de base de données.
require_once dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'GestionBdd.php';

function obtenir_nomTable(): string
{
    return 't_utilisateur_uti';
}

function obtenir_champsConfig(?int $id = null): array
{
    // Les champs dont on veut tester la validité avec les options qu'il faut tester :
    return [
        'pseudo' => [
            'requis' => true,
            'unique' => function(string $pseudo) use ($id) {
                return est_uniqueDansTable("t_utilisateur_uti", "uti_pseudo", $pseudo, "uti_id", $id);
            },
            'minLength' => 2,
            'maxLength' => 255
        ],
        'email' => [
            'requis' => true,
            'unique' => function(string $email) use ($id) {
                return est_uniqueDansTable("t_utilisateur_uti", "uti_email", $email, "uti_id", $id);
            },
            'type' => 'email'
        ],
        'mdp' => [
            'requis' => true,
            'type' => 'password',
            'minLength' => 8,
            'maxLength' => 72
        ]
    ];
}

// Fonction pour enregistrer un utilisateur dans la base de données :
function creer_utilisateur(string $pseudo, string $email, string $mdp): bool
{
    // La requête :
    $table = obtenir_nomTable();
    $requete = "INSERT INTO $table (uti_pseudo, uti_email, uti_motdepasse) VALUES (:pseudo, :email, :motDePasse)";

    // Hashage du mot de passe.
    $mdp = password_hash($mdp, PASSWORD_DEFAULT);

    // Fonction générique présente dans le gestionnaire de base de données (gestion_bdd.php).
    return modifier_dansTable($requete, ['pseudo' => $pseudo, 'email' => $email, 'motDePasse' => $mdp]);
}

// Fonction pour sélectionner un utilisateur :
function selectionner_tousLesutilisateurs(): ?array
{
    // La requête :
    $table = obtenir_nomTable();
    $requete = "SELECT uti_id, uti_pseudo FROM $table";

    // Retourner le résutlat de la requête si celle-ci a été fructueuse, sinon retourner "null".
    return selectionner_dansTable($requete) ?? null;
}

// Fonction pour sélectionner un utilisateur par son ID :
function selectionner_utilisateurParId(int $id): ?array
{
    // La requête :
    $table = obtenir_nomTable();
    $requete = "SELECT uti_id, uti_pseudo, uti_email FROM $table WHERE uti_id = :id";

    // Retourner le résutlat de la requête si celle-ci a été fructueuse, sinon retourner "null".
    return selectionner_dansTable($requete, ['id' => $id])[0] ?? null;
}

// Fonction pour mettre à jour les détails d'un utilisateur :
function actualiser_utilisateur(int $id, string $pseudo, string $email, ?string $mdp = null): bool
{
    // La requête :
    $table = obtenir_nomTable();

    // Vérifier qu'un nouveau mot de passe a été passé en argument $mdp.
    if ($mdp === null)
    {
        // La requête sans mise à jour du mot de passe :
        $requete = "UPDATE $table SET uti_pseudo = :pseudo, uti_email = :email WHERE uti_id = :id";
        $parametres = ['id' => $id, 'pseudo' => $pseudo, 'email' => $email];
    }
    else
    {
        // La requête avec mise à jour du mot de passe :
        $requete = "UPDATE $table SET uti_pseudo = :pseudo, uti_email = :email, uti_motdepasse = :motDePasse WHERE uti_id = :id";
        $parametres = ['id' => $id, 'pseudo' => $pseudo, 'email' => $email, 'motDePasse' => $mdp];
    }

    // Fonction générique présente dans le gestionnaire de base de données (gestion_bdd.php).
    return modifier_dansTable($requete, $parametres);
}

// Fonction pour supprimer un utilisateur de la base de données :
function supprimer_utilisateur(int $id): bool
{
    // La requête :
    $table = obtenir_nomTable();
    $requete = "DELETE FROM $table WHERE uti_id = :id";

    // Fonction générique présente dans le gestionnaire de base de données (gestion_bdd.php).
    return modifier_dansTable($requete, ['id' => $id]);
}