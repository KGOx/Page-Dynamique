<?php
// Importer le gestionnaire de vues.
require_once dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'GestionVue.php';

// Communiquer les informations de la page nécessaire au bon fonctionnement de la vue :
function obtenir_pageInfos(): array
{
    return [
        'vue' => 'accueil',
        'titre' => "Page d'Accueil",
        'description' => "Description de la page d'accueil..."
    ];
}

// index : Afficher la liste des utilisateurs (il s'agit de la partie chargée par défaut) :
function index(): void
{
    // Afficher la vue "vue_accueil.php".
    afficher_vue(obtenir_pageInfos(), 'index');
}
?>