<?php
// Importer le gestionnaire de formulaires.
require_once dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'GestionFormulaire.php';
// Importer le gestionnaire de messages.
require_once dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'GestionMessage.php';
// Importer le gestionnaire de vues.
require_once dirname(__DIR__, 2) . DIRECTORY_SEPARATOR . 'core' . DIRECTORY_SEPARATOR . 'GestionVue.php';
// Importer le modèle des utilisateurs.
require_once dirname(__DIR__) . DIRECTORY_SEPARATOR . 'Models' . DIRECTORY_SEPARATOR . 'UtilisateurModel.php';

// Communiquer les informations de la page nécessaire au bon fonctionnement de la vue :
function obtenir_pageInfos(): array
{
    return [
        'vue' => 'admin_gestion_utilisateur',
        'titre' => "Gestion des Utilisateurs",
        'description' => "Description de la page Gestion des Utilisateurs...",
        'baseUrlPage' => BASE_URL . '/' . 'admin-gestion-utilisateur'
    ];
}

function afficher_vueUtilisateurValide(string $action, array $args)
{
    // Vérifier si l'utilisateur a été trouvé.
    if ($args['utilisateur'] !== null)
    {
        afficher_vue(obtenir_pageInfos(), $action, $args);
    }
    else
    {
        $redirection = obtenir_pageInfos()['baseUrlPage'];
        header("Location: $redirection");
        exit();
    }
}

// index : Afficher la liste des utilisateurs (il s'agit de la partie chargée par défaut) :
function index(?array $args = []): void
{
    // Récupération les données de tous les utilisateurs.
    $args['utilisateurs'] = selectionner_tousLesutilisateurs();

    // Si aucun utilisateur d'a été trouvé convertir la valeur "null" en tableau vide.
    $args['utilisateurs'] = $args['utilisateurs'] ?? [];

    // Appeler la vue.
    afficher_vue(obtenir_pageInfos(), 'index', $args);
}

// show : Afficher les détails d'un utilisateur :
function montrer(string $id, ?array $args = []): void
{
    // Récupération des données de l'utilisateur.
    $args['utilisateur'] = selectionner_utilisateurParId((int)$id);

    // Appeler la vue.
    afficher_vueUtilisateurValide('montrer', $args);
}

// create : Afficher le formulaire de création d'utilisateur :
function creer(?array $args = []): void
{
    // Appeler la vue.
    afficher_vue(obtenir_pageInfos(), 'creer', $args);
}

// store : Enregistrer un nouvel utilisateur dans la base de données à partir des données fournies dans le formulaire de création :
function stocker(): void
{
    // Vérifier la validité des entrées utilisateur.
    $resultat = verifier_validiteChamps(obtenir_champsConfig(), $_POST);

    if (count($resultat['erreurs']) === 0)
    {
        // Ajouter le nouvel utilisateur à la bdd, vérifier et agir en fonction du résultat de la requête (true ou false) :
        if (creer_utilisateur($_POST['pseudo'], $_POST['email'], $_POST['mdp'])) 
        {
            $resultat['messageValidation'] = obtenir_messageValidation('form', 'nouvelUtilisateur_succes');
        }
        else
        {
            $resultat['messageValidation'] = obtenir_messageValidation('form', 'generique_echec', false);
        }
    }
    else
    {
        $resultat['messageValidation'] = obtenir_messageValidation('form', 'champs_echec', false);
    }

    // Réafficher le formulaire de création d'utilisateur.
    creer($resultat);
}

// edit : Afficher le formulaire de modification d'un utilisateur spécifique :
function editer(string $id, ?array $args = []): void
{
    // Récupération des données de l'utilisateur.
    $args['utilisateur'] = selectionner_utilisateurParId((int)$id);

    // Appeler la vue.
    afficher_vueUtilisateurValide('editer', $args);
}

// update : Mettre à jour les détails d'un utilisateur dans la base de données à partir des données fournies dans le formulaire de modification :
function actualiser(string $id): void
{
    // Convertir l'id en entier.
    $id = (int)$id;

        // Récupérer les informations de configuration des champs pour exclure son propre id lors du test d'unicité.
        $champsConfig = obtenir_champsConfig($id);

        // Ne pas forcer le changement du mot de passe.
        $champsConfig['mdp']['requis'] = false;

    // Vérifier la validité des entrées utilisateur.
    $resultat = verifier_validiteChamps($champsConfig, $_POST);

    if (count($resultat['erreurs']) === 0)
    {
        // Si un mot de passe a été entré dans le formulaire, le récupérer pour le mettre à jour dans la bdd.
        $mdp = isset($post['mdp']) && !empty($post['mdp']) ? $post['mdp'] : null;

        // Actualiser les données de l'utilisateur dans la bdd, vérifier et agir en fonction du résultat de la requête (true ou false) :
        if (actualiser_utilisateur($id, $_POST['pseudo'], $_POST['email'], $mdp)) 
        {
            $resultat['messageValidation'] = obtenir_messageValidation('form', 'maj_succes');
        }
        else
        {
            $resultat['messageValidation'] = obtenir_messageValidation('form', 'generique_echec', false);
        }
    }
    else
    {
        $resultat['messageValidation'] = obtenir_messageValidation('form', 'champs_echec', false);
    }

    // Réafficher le formulaire de modification de l'utilisateur.
    editer($id, $resultat);
}

// destroy : Supprimer un utilisateur spécifique de la base de données :
function detruire(): void
{
    // Tentative de suppresion de l'utilisateur.
    $succesDestruction = isset($_POST['id']) && is_numeric($_POST['id']) && supprimer_utilisateur((int)$_POST['id']);

    // Obtenir un message d'erreur si un problème a été rencontré lors de la tentative de suppression d'un utilisateur :
    $resultat =  ['messageValidation' => $succesDestruction ? null : obtenir_messageValidation('form', 'supDansTable_echec', false)];

    // Appeler le contrôleur qui s'occupe d'afficher la liste des utilisateurs et lui passer le message de validation.
    index($resultat);
}
?>